const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.postInteraction = functions.https.onRequest((req, res) => {
  if (req.method !== "POST") {
    return res.status(405).send("Only POST requests are allowed");
  }

  const { timestamp, zone, game, result } = req.body;

  if (!timestamp || !zone || !game || !result) {
    return res.status(400).send("Missing fields: timestamp, zone, game, or result");
  }

  admin.database().ref("interactions").push({
    timestamp,
    zone,
    game,
    result
  })
  .then(() => res.status(200).send("Interaction logged successfully!"))
  .catch(err => res.status(500).send("Error: " + err.message));
});
